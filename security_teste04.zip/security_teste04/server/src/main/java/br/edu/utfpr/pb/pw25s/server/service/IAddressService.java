package br.edu.utfpr.pb.pw25s.server.service;

import br.edu.utfpr.pb.pw25s.server.model.Address;
import br.edu.utfpr.pb.pw25s.server.model.User;

public interface IAddressService extends ICrudService<Address, Long>{
    public void saveStart(User user);
    public Address buscarAddress();
    public void salvarAddress(Address address);
}
