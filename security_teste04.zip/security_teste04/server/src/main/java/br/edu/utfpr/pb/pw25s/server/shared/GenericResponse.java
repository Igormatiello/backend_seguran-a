package br.edu.utfpr.pb.pw25s.server.shared;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GenericResponse {

    private String message;

}
