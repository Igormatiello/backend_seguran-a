package br.edu.utfpr.pb.pw25s.server.security;

import br.edu.utfpr.pb.pw25s.server.model.User;
import br.edu.utfpr.pb.pw25s.server.service.AuthService;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.*;
import com.nimbusds.jwt.EncryptedJWT;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {
    private final AuthService authService;

    private static final String SECRET_T = "01234567890123456789012345678901"; // 32 characters


    public JWTAuthorizationFilter(AuthenticationManager authenticationManager, AuthService authService) {
        super(authenticationManager);
        this.authService = authService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        String header = request.getHeader(SecurityConstants.HEADER_STRING);
        if (header == null || !header.startsWith(SecurityConstants.TOKEN_PREFIX)) {
            chain.doFilter(request, response);
            return;
        }

        String fingerprint = request.getHeader("Fingerprint");
        if (fingerprint == null) {
            response.sendError(HttpStatus.UNAUTHORIZED.value(), "Fingerprint missing");
            return;
        }

        UsernamePasswordAuthenticationToken authentication = getAuthentication(request, fingerprint);
        if (authentication == null) {
            response.sendError(HttpStatus.UNAUTHORIZED.value(), "Invalid token or fingerprint");
            return;
        }


        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(request, response);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request, String fingerprint) {
        String token = request.getHeader(SecurityConstants.HEADER_STRING);
        if (token != null) {
            try {
                EncryptedJWT jwt = EncryptedJWT.parse(token.replace(SecurityConstants.TOKEN_PREFIX, ""));
                byte[] secretKeyBytes = SECRET_T.getBytes(StandardCharsets.UTF_8);
                AESDecrypter decrypter = new AESDecrypter(secretKeyBytes);
                jwt.decrypt(decrypter);

                String user = jwt.getJWTClaimsSet().getSubject();
                String tokenFingerprint = jwt.getJWTClaimsSet().getStringClaim("fingerprint");

                if (user != null && fingerprint.equals(tokenFingerprint)) {
                    User userObj = (User) authService.loadUserByUsername(user);
                    return new UsernamePasswordAuthenticationToken(user, null, userObj.getAuthorities());
                }
            } catch (JOSEException | java.text.ParseException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
