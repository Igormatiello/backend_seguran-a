package br.edu.utfpr.pb.pw25s.server.service;

import br.edu.utfpr.pb.pw25s.server.model.LoginRecord;
import br.edu.utfpr.pb.pw25s.server.model.User;
import br.edu.utfpr.pb.pw25s.server.repository.LoginRecordRepository;
import br.edu.utfpr.pb.pw25s.server.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthService implements UserDetailsService {

    private final UserRepository userRepository;

    private final LoginRecordRepository loginRecordRepository;


    public AuthService(UserRepository userRepository, LoginRecordRepository loginRecordRepository) {
        this.userRepository = userRepository;
        this.loginRecordRepository = loginRecordRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return user;
    }

    public void saveLoginRecord(User user, String ip) {
        LoginRecord loginRecord = LoginRecord.builder()
                .user(user)
                .ip(ip)
                .loginTime(LocalDateTime.now())
                .build();
        loginRecordRepository.save(loginRecord);
    }





}