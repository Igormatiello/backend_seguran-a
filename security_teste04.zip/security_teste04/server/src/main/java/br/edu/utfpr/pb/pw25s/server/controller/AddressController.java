package br.edu.utfpr.pb.pw25s.server.controller;

import br.edu.utfpr.pb.pw25s.server.dto.AddressDto;
import br.edu.utfpr.pb.pw25s.server.dto.CategoryDto;
import br.edu.utfpr.pb.pw25s.server.model.Address;
import br.edu.utfpr.pb.pw25s.server.model.Category;
import br.edu.utfpr.pb.pw25s.server.service.IAddressService;
import br.edu.utfpr.pb.pw25s.server.service.ICategoryService;
import br.edu.utfpr.pb.pw25s.server.shared.GenericResponse;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("address")
public class AddressController {
    private final ModelMapper modelMapper;
    private final IAddressService service;

    public AddressController(ModelMapper modelMapper, IAddressService service) {
        this.modelMapper = modelMapper;
        this.service = service;
    }

    private AddressDto convertToDto(Address address) {
        return modelMapper.map(address, AddressDto.class);
    }

    private Address convertToEntity(AddressDto addressDto) {
        return modelMapper.map(addressDto, Address.class);
    }

    @PostMapping
    public GenericResponse alterar(@RequestBody @Valid AddressDto address) {

        Address address1 = convertToEntity(address);
        service.salvarAddress(address1);

        return GenericResponse.builder().message("Address saved.").build();
    }
    @GetMapping
    public ResponseEntity<AddressDto> findComDto() {
        Address address = service.buscarAddress();
        AddressDto addressDto = convertToDto(address);
        return ResponseEntity.ok(addressDto);
    }

}
