package br.edu.utfpr.pb.pw25s.server.service;

import br.edu.utfpr.pb.pw25s.server.model.User;
import br.edu.utfpr.pb.pw25s.server.repository.UserRepository;
import br.edu.utfpr.pb.pw25s.server.security.SecurityConstants;
import br.edu.utfpr.pb.pw25s.server.service.impl.AddressServiceImpl;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    public UserService(UserRepository userRepository ) {

        this.userRepository = userRepository;

        bCryptPasswordEncoder = new BCryptPasswordEncoder();
    }

    public User save(User user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
       // enviarEmail("igormatiello1122@gmail.com", user.getSecret());
        return userRepository.save(user);
    }




    public User getUserDoToken() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userRepository.findByUsername(username);

    }


    public void enviarEmail(String email, String codigo) {
        try {

            Properties props = new Properties();
            props.setProperty("mail.transport.protocol", "smtp");
            props.setProperty("mail.smtp.auth", "true");

            Session session = Session.getInstance(props);
            session.setDebug(false);

            Transport transport = session.getTransport("smtp");
            transport.connect("smtplw.com.br", 587, "", "");

            try {

                ByteArrayOutputStream outputStream = null;

                outputStream = new ByteArrayOutputStream();

                // byte[] bytes = outputStream.toByteArray();
                // DataSource dataSource = new ByteArrayDataSource(bytes, "application/pdf");

                Message message = new MimeMessage(session);

                InternetAddress enviadoPor = new InternetAddress("",
                        "email automatico");
                message.setFrom(enviadoPor);

                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email.replace(";", ",")));

                message.setSubject("Confirmação de cadastro");

                BodyPart messageBodyPart1 = new MimeBodyPart();

                String mensagem = "";

                mensagem = "Olá, seu código TOTP é " + codigo;

                messageBodyPart1.setContent(mensagem, "text/html; charset=utf-8");
                // MimeBodyPart messageBodyPart2 = new MimeBodyPart();
                // messageBodyPart2.setDataHandler(new DataHandler(dataSource));
                // messageBodyPart2.setFileName("fatura.pdf");
                Multipart multipart = new MimeMultipart();
                multipart.addBodyPart(messageBodyPart1);
                // multipart.addBodyPart(messageBodyPart2);
                message.setContent(multipart);
                message.saveChanges();

                transport.sendMessage(message, message.getAllRecipients());
                ZonedDateTime zonedDateTime = ZonedDateTime.now(ZoneId.of("America/Cuiaba"));
                LocalDateTime localDateTime = zonedDateTime.toLocalDateTime();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                String formattedDateTime = localDateTime.format(formatter);

            } finally {
                transport.close();
            }

        } catch (Exception e) {


        }

    }


}